# Cricket Live – Spring Boot

Simulated real-time cricket scoring platform (Java 17, Maven, no database needed).

## Run
    mvn spring-boot:run
Open http://localhost:8080

## REST API
| Method | Path | Description |
|---|---|---|
| GET | /api/matches | All matches with live scores |
| GET | /api/matches/{id} | One match (scores, commentary, current batters/bowler) |
| GET | /api/matches/{id}/players | Batting & bowling stats per team |
| GET | /api/matches/{id}/summary | Result, top scorer, best bowler |
| POST | /api/matches?teamA=&teamB=&overs= | Start a new simulated match |
| GET | /api/stream | Server-Sent Events push of live scores |

## How it works
- `@Scheduled` engine bowls one ball per live match every 1.5s; new matches auto-start when all finish.
- Scores are pushed to browsers over SSE (no polling); state is in a ConcurrentHashMap, per-match locks.
- Scale-out ideas: move state to Redis, publish ball events via Kafka, run stateless instances behind a load balancer.
